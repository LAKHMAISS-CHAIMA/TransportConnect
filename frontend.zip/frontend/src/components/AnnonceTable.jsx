import React from 'react';

const AnnonceTable = ({ annonces = [] }) => (
  <table className="min-w-full bg-white border">
    <thead>
      <tr>
        <th className="py-2 px-4 border">Départ</th>
        <th className="py-2 px-4 border">Destination</th>
        <th className="py-2 px-4 border">Date</th>
        <th className="py-2 px-4 border">Conducteur</th>
      </tr>
    </thead>
    <tbody>
      {annonces.length === 0 ? (
        <tr><td colSpan={4} className="text-center py-4">Aucune annonce</td></tr>
      ) : (
        annonces.map((a, i) => (
          <tr key={i}>
            <td className="border px-4 py-2">{a.depart || '-'}</td>
            <td className="border px-4 py-2">{a.destination || '-'}</td>
            <td className="border px-4 py-2">{a.dateTrajet ? new Date(a.dateTrajet).toLocaleDateString() : '-'}</td>
            <td className="border px-4 py-2">{a.conducteur?.email || '-'}</td>
          </tr>
        ))
      )}
    </tbody>
  </table>
);

export default AnnonceTable;
