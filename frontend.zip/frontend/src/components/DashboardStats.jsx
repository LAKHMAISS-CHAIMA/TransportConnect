import React, { useEffect, useState } from 'react';
import axios from 'axios';

const DashboardStats = () => {
  const [stats, setStats] = useState({ users: 0, trajets: 0, taux: 0 });

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const token = localStorage.getItem('token');
        const res = await axios.get('/api/admin/stats', {
          headers: { Authorization: `Bearer ${token}` },
        });
        setStats(res.data);
      } catch (err) {
        console.error('Erreur stats admin:', err);
      }
    };
    fetchStats();
  }, []);

  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
      <div className="p-4 bg-blue-100 rounded">
        <h3 className="text-xl font-semibold">Utilisateurs</h3>
        <p className="text-2xl">{stats.users}</p>
      </div>
      <div className="p-4 bg-green-100 rounded">
        <h3 className="text-xl font-semibold">Trajets</h3>
        <p className="text-2xl">{stats.trajets}</p>
      </div>
      <div className="p-4 bg-yellow-100 rounded">
        <h3 className="text-xl font-semibold">Taux acceptation</h3>
        <p className="text-2xl">{stats.taux}%</p>
      </div>
    </div>
  );
};

export default DashboardStats;
