import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Navbar = () => {
  const { isAuthenticated, user, logout } = useAuth();
  return (
    <nav className="bg-red-700 text-white px-4 py-3 flex justify-between items-center">
      <div className="font-bold text-xl">
        <Link to="/dashboard">TransportConnect</Link>
      </div>
      <div className="flex gap-4 items-center">
        {isAuthenticated && user && (
          <>
            <Link to="/dashboard">Dashboard</Link>
            <Link to="/create-annonce">Créer Annonce</Link>
            <span className="hidden sm:inline">{user.firstname} {user.lastname}</span>
            <button onClick={logout} className="bg-white text-red-700 px-3 py-1 rounded font-bold hover:bg-red-100">Déconnexion</button>
          </>
        )}
        {!isAuthenticated && (
          <>
            <Link to="/login">Connexion</Link>
            <Link to="/register">Créer un compte</Link>
          </>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
