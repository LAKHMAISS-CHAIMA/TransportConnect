import React, { useEffect, useState } from "react";
import axios from "axios";

const API_URL = "/api/admin";

const roles = {
  admin: "Administrateur",
  conducteur: "Chauffeur",
  expediteur: "Expéditeur"
};

export default function AdminDashboard() {
  const [users, setUsers] = useState([]);
  const [annonces, setAnnonces] = useState([]);
  const [stats, setStats] = useState({ users: 0, annonces: 0, demandes: 0 });
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  // Fetch all data
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const [usersRes, annoncesRes, statsRes] = await Promise.all([
          axios.get(`${API_URL}/users`),
          axios.get(`${API_URL}/annonces`),
          axios.get(`${API_URL}/stats`)
        ]);
        setUsers(Array.isArray(usersRes.data) ? usersRes.data : []);
        setAnnonces(Array.isArray(annoncesRes.data) ? annoncesRes.data : []);
        setStats(statsRes.data);
        setError("");
      } catch (err) {
        setError("Erreur de connexion au serveur. Réessayez plus tard !");
      }
      setLoading(false);
    };
    fetchData();
  }, []);

  // Delete user
  const handleDeleteUser = async (id) => {
    if (!window.confirm("Êtes-vous sûr de vouloir supprimer cet utilisateur ?")) return;
    try {
      await axios.delete(`${API_URL}/users/${id}`);
      setUsers(users.filter((u) => u._id !== id));
      setMessage("Utilisateur supprimé avec succès !");
      setError("");
    } catch {
      setError("Impossible de supprimer l'utilisateur. Réessayez plus tard !");
    }
  };

  // Change user role
  const handleChangeRole = async (id, currentRole) => {
    const newRole = currentRole === "conducteur" ? "expediteur" : "conducteur";
    try {
      await axios.put(`${API_URL}/users/${id}`, { role: newRole });
      setUsers(users.map((u) => (u._id === id ? { ...u, role: newRole } : u)));
      setMessage("Rôle modifié avec succès !");
      setError("");
    } catch {
      setError("Impossible de changer le rôle. Réessayez plus tard !");
    }
  };

  // Delete annonce
  const handleDeleteAnnonce = async (id) => {
    if (!window.confirm("Voulez-vous vraiment supprimer cette annonce ?")) return;
    try {
      await axios.delete(`${API_URL}/annonces/${id}`);
      setAnnonces(annonces.filter((a) => a._id !== id));
      setMessage("Annonce supprimée avec succès !");
      setError("");
    } catch {
      setError("Impossible de supprimer l'annonce. Réessayez plus tard !");
    }
  };

  return (
    <div className="p-6 bg-gradient-to-br from-orange-100 to-yellow-50 min-h-screen">
      <h1 className="text-3xl font-bold mb-4 text-orange-700">Bienvenue sur le tableau de bord admin ! 🧉</h1>
      <p className="mb-6 text-gray-600">Gérez tout le système comme un vrai caïd marocain !</p>

      {message && <div className="mb-4 p-2 bg-green-100 text-green-700 rounded">{message}</div>}
      {error && <div className="mb-4 p-2 bg-red-100 text-red-700 rounded">{error}</div>}

      {loading ? (
        <div className="text-center text-orange-600">⏳ Chargement des données... Patientez un peu !</div>
      ) : (
        <>
          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            <div className="bg-white rounded shadow p-4 flex flex-col items-center border-b-4 border-orange-400">
              <span className="text-2xl font-bold text-orange-700">{stats.users}</span>
              <span className="text-gray-600">Utilisateurs</span>
            </div>
            <div className="bg-white rounded shadow p-4 flex flex-col items-center border-b-4 border-green-400">
              <span className="text-2xl font-bold text-green-700">{stats.annonces}</span>
              <span className="text-gray-600">Annonces</span>
            </div>
            <div className="bg-white rounded shadow p-4 flex flex-col items-center border-b-4 border-blue-400">
              <span className="text-2xl font-bold text-blue-700">{stats.demandes}</span>
              <span className="text-gray-600">Demandes</span>
            </div>
          </div>

          {/* Users Table */}
          <h2 className="text-xl font-bold mb-2 text-orange-700">Utilisateurs</h2>
          <div className="overflow-x-auto mb-8">
            <table className="min-w-full bg-white rounded shadow">
              <thead>
                <tr className="bg-orange-200 text-orange-900">
                  <th className="py-2 px-4">Nom</th>
                  <th className="py-2 px-4">Email</th>
                  <th className="py-2 px-4">Rôle</th>
                  <th className="py-2 px-4">Actions</th>
                </tr>
              </thead>
              <tbody>
                {(Array.isArray(users) ? users : []).map((u) => (
                  <tr key={u._id} className="border-b">
                    <td className="py-2 px-4">{u.name}</td>
                    <td className="py-2 px-4">{u.email}</td>
                    <td className="py-2 px-4">{roles[u.role] || u.role}</td>
                    <td className="py-2 px-4 flex gap-2">
                      <button
                        className="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded"
                        onClick={() => handleDeleteUser(u._id)}
                      >Supprimer</button>
                      {u.role !== "admin" && (
                        <button
                          className="bg-blue-500 hover:bg-blue-600 text-white px-3 py-1 rounded"
                          onClick={() => handleChangeRole(u._id, u.role)}
                        >Changer rôle</button>
                      )}
                    </td>
                  </tr>
                ))}
                {users.length === 0 && (
                  <tr><td colSpan="4" className="text-center py-4">Aucun utilisateur trouvé !</td></tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Annonces Table */}
          <h2 className="text-xl font-bold mb-2 text-orange-700">Annonces</h2>
          <div className="overflow-x-auto mb-8">
            <table className="min-w-full bg-white rounded shadow">
              <thead>
                <tr className="bg-green-200 text-green-900">
                  <th className="py-2 px-4">Titre</th>
                  <th className="py-2 px-4">Expéditeur</th>
                  <th className="py-2 px-4">Statut</th>
                  <th className="py-2 px-4">Actions</th>
                </tr>
              </thead>
              <tbody>
                {(Array.isArray(annonces) ? annonces : []).map((a) => (
                  <tr key={a._id} className="border-b">
                    <td className="py-2 px-4">{a.titre || a.title}</td>
                    <td className="py-2 px-4">{a.expediteurName || a.expediteur?.name || "-"}</td>
                    <td className="py-2 px-4">{a.statut || a.status || "-"}</td>
                    <td className="py-2 px-4">
                      <button
                        className="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded"
                        onClick={() => handleDeleteAnnonce(a._id)}
                      >Supprimer</button>
                    </td>
                  </tr>
                ))}
                {annonces.length === 0 && (
                  <tr><td colSpan="4" className="text-center py-4">Aucune annonce trouvée !</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}
// Touche marocaine : emoji thé, phrase d'accueil, couleurs chaudes.
