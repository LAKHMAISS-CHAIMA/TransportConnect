import React from "react";
const AnnonceSearch = () => (
  <div className="p-8 text-center">
    <h2 className="text-2xl font-bold mb-4">Recherche d'annonces</h2>
    <p>Filtrer et voir les annonces disponibles.</p>
  </div>
);
export default AnnonceSearch; 