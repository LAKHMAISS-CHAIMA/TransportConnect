import React, { useEffect, useState } from "react";
import axios from "axios";

const API_URL = "/api/conducteur";

export default function ConducteurDashboard() {
  const [annonces, setAnnonces] = useState([]);
  const [demandes, setDemandes] = useState([]);
  const [stats, setStats] = useState({ annonces: 0, demandes: 0, acceptées: 0, refusées: 0 });
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [form, setForm] = useState({ titre: "", description: "", date: "" });
  const [creating, setCreating] = useState(false);

  // Charger les données
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const [annoncesRes, demandesRes, statsRes] = await Promise.all([
          axios.get(`${API_URL}/annonces`),
          axios.get(`${API_URL}/demandes`),
          axios.get(`${API_URL}/stats`)
        ]);
        setAnnonces(Array.isArray(annoncesRes.data) ? annoncesRes.data : []);
        setDemandes(Array.isArray(demandesRes.data) ? demandesRes.data : []);
        setStats(statsRes.data);
        setError("");
      } catch (err) {
        setError("Erreur de connexion au serveur. Réessayez plus tard !");
      }
      setLoading(false);
    };
    fetchData();
  }, []);

  // Créer une annonce
  const handleCreateAnnonce = async (e) => {
    e.preventDefault();
    setCreating(true);
    try {
      const res = await axios.post(`${API_URL}/annonces`, form);
      setAnnonces([res.data, ...annonces]);
      setForm({ titre: "", description: "", date: "" });
      setMessage("Annonce créée avec succès !");
      setError("");
    } catch {
      setError("Impossible de créer l'annonce. Vérifiez les champs et réessayez !");
    }
    setCreating(false);
  };

  // Supprimer une annonce
  const handleDeleteAnnonce = async (id) => {
    if (!window.confirm("Voulez-vous vraiment supprimer cette annonce ?")) return;
    try {
      await axios.delete(`${API_URL}/annonces/${id}`);
      setAnnonces(annonces.filter((a) => a._id !== id));
      setMessage("Annonce supprimée avec succès !");
      setError("");
    } catch {
      setError("Impossible de supprimer l'annonce. Réessayez plus tard !");
    }
  };

  // Accepter une demande
  const handleAccepter = async (id) => {
    try {
      await axios.put(`${API_URL}/demandes/${id}/accept`);
      setDemandes(demandes.map((d) => (d._id === id ? { ...d, statut: "acceptée" } : d)));
      setMessage("Demande acceptée !");
      setError("");
    } catch {
      setError("Impossible d'accepter la demande. Réessayez plus tard !");
    }
  };

  // Refuser une demande
  const handleRefuser = async (id) => {
    try {
      await axios.put(`${API_URL}/demandes/${id}/refuse`);
      setDemandes(demandes.map((d) => (d._id === id ? { ...d, statut: "refusée" } : d)));
      setMessage("Demande refusée !");
      setError("");
    } catch {
      setError("Impossible de refuser la demande. Réessayez plus tard !");
    }
  };

  return (
    <div className="p-6 bg-gradient-to-br from-green-100 to-yellow-50 min-h-screen">
      <h1 className="text-3xl font-bold mb-4 text-green-700">Bienvenue chauffeur ! 🚚</h1>
      <p className="mb-6 text-gray-600">Gérez vos annonces et vos demandes comme un pro du bled !</p>

      {message && <div className="mb-4 p-2 bg-green-100 text-green-700 rounded">{message}</div>}
      {error && <div className="mb-4 p-2 bg-red-100 text-red-700 rounded">{error}</div>}

      {loading ? (
        <div className="text-center text-green-600">⏳ Chargement des données... Patientez un peu !</div>
      ) : (
        <>
          {/* Statistiques */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <div className="bg-white rounded shadow p-4 flex flex-col items-center border-b-4 border-green-400">
              <span className="text-2xl font-bold text-green-700">{stats.annonces}</span>
              <span className="text-gray-600">Mes annonces</span>
            </div>
            <div className="bg-white rounded shadow p-4 flex flex-col items-center border-b-4 border-yellow-400">
              <span className="text-2xl font-bold text-yellow-700">{stats.demandes}</span>
              <span className="text-gray-600">Demandes reçues</span>
            </div>
            <div className="bg-white rounded shadow p-4 flex flex-col items-center border-b-4 border-blue-400">
              <span className="text-2xl font-bold text-blue-700">{stats.acceptées}</span>
              <span className="text-gray-600">Demandes acceptées</span>
            </div>
            <div className="bg-white rounded shadow p-4 flex flex-col items-center border-b-4 border-red-400">
              <span className="text-2xl font-bold text-red-700">{stats.refusées}</span>
              <span className="text-gray-600">Demandes refusées</span>
            </div>
          </div>

          {/* Formulaire création annonce */}
          <h2 className="text-xl font-bold mb-2 text-green-700">Créer une nouvelle annonce</h2>
          <form onSubmit={handleCreateAnnonce} className="bg-white rounded shadow p-4 mb-8 flex flex-col gap-4 max-w-xl">
            <input
              type="text"
              placeholder="Titre de l'annonce"
              className="border p-2 rounded"
              value={form.titre}
              onChange={e => setForm({ ...form, titre: e.target.value })}
              required
            />
            <textarea
              placeholder="Description"
              className="border p-2 rounded"
              value={form.description}
              onChange={e => setForm({ ...form, description: e.target.value })}
              required
            />
            <input
              type="date"
              className="border p-2 rounded"
              value={form.date}
              onChange={e => setForm({ ...form, date: e.target.value })}
              required
            />
            <button
              type="submit"
              className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded font-bold"
              disabled={creating}
            >{creating ? "Création..." : "Créer l'annonce"}</button>
          </form>

          {/* Mes annonces */}
          <h2 className="text-xl font-bold mb-2 text-green-700">Mes annonces</h2>
          <div className="overflow-x-auto mb-8">
            <table className="min-w-full bg-white rounded shadow">
              <thead>
                <tr className="bg-green-200 text-green-900">
                  <th className="py-2 px-4">Titre</th>
                  <th className="py-2 px-4">Description</th>
                  <th className="py-2 px-4">Date</th>
                  <th className="py-2 px-4">Actions</th>
                </tr>
              </thead>
              <tbody>
                {(Array.isArray(annonces) ? annonces : []).map((a) => (
                  <tr key={a._id} className="border-b">
                    <td className="py-2 px-4">{a.titre || a.title}</td>
                    <td className="py-2 px-4">{a.description}</td>
                    <td className="py-2 px-4">{a.date ? new Date(a.date).toLocaleDateString() : "-"}</td>
                    <td className="py-2 px-4">
                      <button
                        className="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded"
                        onClick={() => handleDeleteAnnonce(a._id)}
                      >Supprimer</button>
                    </td>
                  </tr>
                ))}
                {annonces.length === 0 && (
                  <tr><td colSpan="4" className="text-center py-4">Aucune annonce trouvée !</td></tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Demandes reçues */}
          <h2 className="text-xl font-bold mb-2 text-green-700">Demandes reçues</h2>
          <div className="overflow-x-auto mb-8">
            <table className="min-w-full bg-white rounded shadow">
              <thead>
                <tr className="bg-yellow-200 text-yellow-900">
                  <th className="py-2 px-4">Annonce</th>
                  <th className="py-2 px-4">Expéditeur</th>
                  <th className="py-2 px-4">Statut</th>
                  <th className="py-2 px-4">Actions</th>
                </tr>
              </thead>
              <tbody>
                {(Array.isArray(demandes) ? demandes : []).map((d) => (
                  <tr key={d._id} className="border-b">
                    <td className="py-2 px-4">{d.annonceTitre || d.annonce?.titre || "-"}</td>
                    <td className="py-2 px-4">{d.expediteurName || d.expediteur?.name || "-"}</td>
                    <td className="py-2 px-4">{d.statut || d.status || "-"}</td>
                    <td className="py-2 px-4 flex gap-2">
                      {d.statut !== "acceptée" && (
                        <button
                          className="bg-blue-500 hover:bg-blue-600 text-white px-3 py-1 rounded"
                          onClick={() => handleAccepter(d._id)}
                        >Accepter</button>
                      )}
                      {d.statut !== "refusée" && (
                        <button
                          className="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded"
                          onClick={() => handleRefuser(d._id)}
                        >Refuser</button>
                      )}
                    </td>
                  </tr>
                ))}
                {demandes.length === 0 && (
                  <tr><td colSpan="4" className="text-center py-4">Aucune demande reçue !</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}
// Touche marocaine : emoji camion, phrase d'accueil, couleurs chaudes.
