import React from "react";
const CreateAnnonce = () => (
  <div className="p-8 text-center">
    <h2 className="text-2xl font-bold mb-4">Créer une annonce</h2>
    <p>Formulaire de création d'annonce pour conducteur.</p>
  </div>
);
export default CreateAnnonce;
