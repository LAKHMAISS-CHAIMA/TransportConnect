import React from "react";
const ExpediteurDashboard = () => (
  <div className="p-8 text-center">
    <h2 className="text-2xl font-bold mb-4">Dashboard Expéditeur</h2>
    <p>Recherche annonces, mes demandes, historique, évaluations...</p>
  </div>
);
export default ExpediteurDashboard;
