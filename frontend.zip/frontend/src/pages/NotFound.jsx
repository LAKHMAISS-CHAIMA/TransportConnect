import React from 'react';

const NotFound = () => (
  <div className="text-center p-10 text-2xl font-semibold text-red-700">
    ⚠️ Page non trouvée
  </div>
);

export default NotFound;
