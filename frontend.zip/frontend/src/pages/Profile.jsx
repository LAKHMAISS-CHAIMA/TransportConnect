import React from "react";
const Profile = () => (
  <div className="p-8 text-center">
    <h2 className="text-2xl font-bold mb-4">Mon Profil</h2>
    <p>Modifier mes informations personnelles ici.</p>
  </div>
);
export default Profile;
